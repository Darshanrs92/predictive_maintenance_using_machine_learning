import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime,timedelta 
from sklearn.preprocessing import Normalizer
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import confusion_matrix
from flask import Flask, jsonify, request
import joblib
import math

# https://www.tutorialspoint.com/flask
import flask
app = Flask(__name__)

#https://stackoverflow.com/questions/60057405/python-convert-list-of-strings-to-floats-with-empty-none
def try_float(ele):
    try:
        return float(ele)
    except Exception:
        return float('nan')

features_min=joblib.load('features_min.pkl',mmap_mode=None)
features_max=joblib.load('features_max.pkl',mmap_mode=None)
medians_average=joblib.load('medians_average.pkl',mmap_mode=None)
clf = joblib.load('model.pkl',mmap_mode=None)
print(len(features_min))
print(len(features_max))
print(len(medians_average))

@app.route('/')
def hello_world():
    return 'Hello World!'


@app.route('/predictive_maintenance')
def predictive_maintenance():
    return flask.render_template('predictive_maintenance.html')


@app.route('/predict', methods=['POST'])



def predict():
    inputs = request.form.to_dict()
    sensor_inputs = inputs['sensor_inputs']
    inputs = sensor_inputs
    
    #converting single string in to a list of strings
    inputs=inputs.split(',')
    
    
    #removing some features(because model is trained without these features)
    unwanted = [0, 1, 17]
    for ele in sorted(unwanted, reverse = True): 
        del inputs[ele]
    
    # converting list of strings in to list of floats
    lst=[]
    for ele in inputs:
        lst.append(try_float(ele))
    inputs = lst
    
    #adding polynomial features
    sensor_04_square=inputs[4]**2
    inputs.append(sensor_04_square)
    sensor_10_square=inputs[10]**2
    inputs.append(sensor_10_square)
    sensor_11_square=inputs[11]**2
    inputs.append(sensor_11_square)
    sensor_00_square=inputs[0]**2
    inputs.append(sensor_00_square)
    sensor_02_square=inputs[2]**2
    inputs.append(sensor_02_square)
    
    #adding average feature
    inputs.append((inputs[4]+inputs[10]+inputs[11]+inputs[0]+inputs[2])/5)
   
    
    #min_max normalization
    lst=[]
    for i,ele in enumerate(inputs):
        lst.append((ele-float(features_min[i][1]))/(float(features_max[i][1])-float(features_min[i][1])))
    inputs = lst
  
    
    #Filling the missing values
    for i,ele in enumerate(inputs):
        if math.isnan(ele):
            inputs[i] = medians_average[i][1]
   
 
    #predicting class label
    pred=clf.predict([inputs])[0]
    #print(pred)
    if pred == 0:
        prediction = "Machine will not become faulty in next 2 hours"
    else:
        prediction = "Machine will become faulty in next 2 hours"
    
    return jsonify({'prediction': prediction})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
  
        